module com.example.breakoutclonefx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;

    opens view.ballTypes to javafx.fxml;
    exports view.ballTypes;
    exports view.brickTypes;
    opens view.brickTypes to javafx.fxml;
    exports view.gameinterface;
    opens view.gameinterface to javafx.fxml;
    exports view.gameequipment;
    opens view.gameequipment to javafx.fxml;
    exports controller;
    opens controller to javafx.fxml;
}
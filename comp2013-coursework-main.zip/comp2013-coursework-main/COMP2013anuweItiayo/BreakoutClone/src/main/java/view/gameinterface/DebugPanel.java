package view.gameinterface;

import view.gameequipment.Wall;

import javax.swing.*;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * this class is responsible for..
 * Changes:
 *  - DebugPanel no longer implements keyboard and mouse listeners.
 *      Those methods have been moved to the DebugConsoleController.
 *  - The member variable names have been changed to begin with m_
 *
 */
public class DebugPanel extends JPanel {

    private Color m_backgroundColor = Color.WHITE;
    private JButton m_skipLevel;
    private JButton m_resetBalls;
    private JSlider m_ballXSpeed;
    private JSlider m_ballYSpeed;
    private Wall m_wall;
    private int m_ballSpeedDiff = 4;
    /**
     * @param wall the wall made up of bricks used as part of the game
     */
    public DebugPanel(Wall wall) {

        this.m_wall = wall;

        Initialize();

        m_skipLevel = MakeButton("Skip Level", e -> wall.nextLevel());
        m_resetBalls = MakeButton("Reset Balls", e -> wall.resetBallCount());

        m_ballXSpeed = MakeSlider(-m_ballSpeedDiff, m_ballSpeedDiff, e -> wall.setBallXSpeed(m_ballXSpeed.getValue()));
        m_ballYSpeed = MakeSlider(-m_ballSpeedDiff, m_ballSpeedDiff, e -> wall.setBallYSpeed(m_ballYSpeed.getValue()));

        this.add(m_skipLevel);
        this.add(m_resetBalls);

        this.add(m_ballXSpeed);
        this.add(m_ballYSpeed);

    }

    /**
     *Initialises the panel with a specific background colour and grid layout
     * The parameters in the grid layout function represent the number of rows and columns respectively
     */
    public void Initialize() {
        this.setBackground(m_backgroundColor);
        this.setLayout(new GridLayout(2, 2));
    }

    /**
     * @param title the name of the button
     * @param e receives inputs from the user when the button is interacted with
     * @return a button with a name and an action listener
     */
    public JButton MakeButton(String title, ActionListener e) {
        JButton out = new JButton(title);
        out.addActionListener(e);
        return out;
    }

    /**
     * @param min the minimum value that the slider can be set to
     * @param max the maximum value that the slider can be set to
     * @param e records events where a change has been made to the slider by the user
     * @return
     */
    public JSlider MakeSlider(int min, int max, ChangeListener e) {
        JSlider out = new JSlider(min, max);
        out.setMajorTickSpacing(1);
        out.setSnapToTicks(true);
        out.setPaintTicks(true);
        out.addChangeListener(e);
        return out;
    }

    /**
     * @param x how fast the ball will move along the x-axis
     * @param y how fast the ball will move along the y-axis
     */
    public void SetValues(int x, int y) {
        m_ballXSpeed.setValue(x);
        m_ballYSpeed.setValue(y);
    }

}

package view.gameinterface;

import controller.GameBoardController;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import javax.swing.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * This class is for the start page, and contains a button for starting the game, and
 * changing the theme.
 */
public class StartPage extends Application {

    private boolean m_isPink = false;
    private int m_sceneWidth = 960;
    private int m_sceneHeight = 540;
    private final int m_translateTitleY = -125;
    private final int m_startBtnWidth = 200;
    private final int m_startBtnHeight = 100;
    private final int m_translateSBtnY = 175;
    private final int m_translateCBtnY = 90;
    private final int m_pinkModeBtnWidth = 350;
    private final int m_pinkModeBtnHeight = 100;
    private final int m_btnFontSize = 55;
    private final int m_titleFontSize = 80;
    private final Font m_colourBtnFont = Font.font("Bodoni MT Condensed", FontWeight.BOLD, FontPosture.REGULAR, m_btnFontSize);
    public int GetM_startBtnWidth() {
        return m_startBtnWidth;
    }

    public int GetM_sceneHeight() {
        return m_sceneHeight;
    }

    public void SetM_sceneHeight(int m_sceneHeight) {
        this.m_sceneHeight = m_sceneHeight;
    }

    public int GetM_sceneWidth() {
        return m_sceneWidth;
    }

    public void SetM_sceneWidth(int m_sceneWidth) {
        this.m_sceneWidth = m_sceneWidth;
    }

    public int GetM_titleFontSize() {
        return m_titleFontSize;
    }

    public boolean IsPink() {
        return m_isPink;
    }

    public void SetM_isPink(boolean pink) {
        m_isPink = pink;
    }

    /**
     * This function will create labels, buttons, format them and add them to the stage.
     * @param homeStage the stage that the start page will appear on
     * @throws IOException Input or output exceptions that may occur
     */
    @Override
    public void start(Stage homeStage) throws IOException {

        //making the scene and the main pane
        StackPane root = new StackPane();
        Scene scene = new Scene(root, GetM_sceneWidth(), GetM_sceneHeight());
//        Color c = Color.rgb(216, 208, 192);
//        scene.setFill(c);

        Button btn = new Button("START");
        btn.setOnAction(e-> {
            SwingUtilities.invokeLater(()->GameBoardController.GameBoardControllerInstance(m_isPink));
            //SwingUtilities.invokeLater(()->new GameBoardController(m_isPink));
                Platform.setImplicitExit(false);
                homeStage.hide();

        });

        root.getChildren().add(btn);

        //title label
        Label title  = new Label("BREAKOUT CLONE");
        title.setFont(Font.font("Bodoni MT Condensed", FontWeight.BOLD, FontPosture.REGULAR, GetM_titleFontSize()));
        title.setTextFill(Color.MAGENTA);
        title.setAlignment(Pos.TOP_CENTER);
        root.getChildren().add(title);

        //setting the background
        String filepath = "C:\\Desktop\\Second-year\\DMS\\DMS Coursework\\comp2013-coursework\\COMP2013anuweItiayo\\BreakoutClone\\src\\main\\java\\images\\wallpaper.gif";
        InputStream stream = new FileInputStream(filepath);
        Image wallpaper = new Image(stream);
        BackgroundImage bgImage;
        BackgroundRepeat bnr = BackgroundRepeat.NO_REPEAT;
        BackgroundPosition bdp = BackgroundPosition.DEFAULT;
        BackgroundSize bds = BackgroundSize.DEFAULT;
        bgImage = new BackgroundImage(wallpaper, bnr, bnr, bdp, bds);
        root.setBackground(new Background(bgImage));

        title.setTranslateY(m_translateTitleY);

        btn.setMaxSize(m_startBtnWidth, m_startBtnHeight);
        btn.setTranslateY(m_translateSBtnY);
        btn.setPickOnBounds(true);
        btn.setText("START");
        btn.setTextFill(Color.WHITE);
        btn.setFont(m_colourBtnFont);
        btn.setStyle("-fx-background-color: transparent;");

        Button colorBtn = new Button();
        colorBtn.setMaxSize(m_pinkModeBtnWidth, m_pinkModeBtnHeight);
        colorBtn.setTranslateY(m_translateCBtnY);
        colorBtn.setPickOnBounds(true);
        colorBtn.setText("PINK MODE");
        colorBtn.setTextFill(Color.WHITE);

        colorBtn.setFont(Font.font("Bodoni MT Condensed", FontWeight.BOLD, FontPosture.REGULAR, m_btnFontSize));

        colorBtn.setStyle("-fx-background-color: transparent;");

        colorBtn.setOnAction(e-> {
            if(colorBtn.getText().equals("PINK MODE")){
                colorBtn.setText("NORMAL MODE");
                //change colours to pink
                m_isPink = true;
            }else{
                colorBtn.setText("PINK MODE");
                //change to normal colours
                SetM_isPink(false);
            }
        });
        root.getChildren().add(colorBtn);

        // btn.setBackground(new BackgroundFill(Color.TRANSPARENT, cornerRadii.NO, NULL));
        //adding the scene to the stage
        homeStage.setScene(scene);
        homeStage.setResizable(false);
        homeStage.show();
    }



}
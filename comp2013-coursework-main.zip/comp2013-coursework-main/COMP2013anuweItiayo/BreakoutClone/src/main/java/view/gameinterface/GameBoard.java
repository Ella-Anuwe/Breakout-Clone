package view.gameinterface;

import controller.DebugConsoleController;
import view.ballTypes.Ball;
import view.brickTypes.Brick;
import view.gameequipment.CountdownTimer;
import view.gameequipment.Paddle;
import view.gameequipment.Wall;

import javax.swing.*;
import java.awt.*;
import java.awt.font.FontRenderContext;


/**
 * Programing conventions that have been violated:
 * 1. Methods do not have tags
 * 2. The debug panel would not show because ctrl+alt+f1 doesn't work. Changed to ctrl shift space.
 * 3. != has been changed to == false
 */

/**
 * This class is responsible for containing all of the components needed for the game
 * such as a timer (for the game logic), a wall, buttons, and other components needed to
 * make up the game
 * Changes made:
 * 1. Static variables removed
 * 2. Variables renamed
 * 3. Public methods begin with capital letter
 */
public class GameBoard extends JComponent{

    private final String CONTINUE = "Continue";
    private final String RESTART = "Restart";
    private final String EXIT = "Exit";
    private final String PAUSE = "Pause Menu";
    private final int TEXT_SIZE = 30;
    private final Color MENU_COLOR = new Color(0, 255, 0);
    private final int DEF_WIDTH = 600;
    private final int DEF_HEIGHT = 450;
    private Color BG_COLOR = Color.WHITE;
    private Timer m_gameTimer;
    private Wall m_wall;
    private CountdownTimer m_clock = new CountdownTimer();
    private String m_message;
    private final int m_initialTime = 200;
    private boolean m_isPink = false;
    private boolean m_showPauseMenu;
    private DebugConsoleController m_dcc;
    private Font m_menuFont;
    private Rectangle m_continueButtonRect;
    private Rectangle m_exitButtonRect;
    private Rectangle m_restartButtonRect;
    private int m_strLen;
    private DebugConsole m_debugConsole;

    /**
     *
     * @return the list of options displayed when the game is paused
     */
    public boolean GetM_showPauseMenu(){
        return m_showPauseMenu;
    }

    /**
     *
     * @return the timer needed for the underlying logic of the game
     */
    public Timer GetM_gameTimer(){
        return m_gameTimer;
    }
    /**
     *
     * @return a button that when clicked restarts the game
     */
    public Rectangle GetM_restartButtonRect() {
        return m_restartButtonRect;
    }



    public CountdownTimer GetM_clock() {
        return m_clock;
    }


    public int GetM_strLen() {
        return m_strLen;
    }

    /**
     *
     * @return the console used to reset the game, reset the balls, change the speed ext.
     */
    public DebugConsole GetM_debugConsole() {
        return m_debugConsole;
    }

    /**
     *
     * @return the button used to continue the game
     */
    public Rectangle GetM_continueButtonRect(){
        return m_continueButtonRect;
    }

    /**
     * @return
     */
    public Wall GetM_wall() {
        return this.m_wall;
    }

    /**
     *
     * @return a button that when clicked exits the game
     */
    public Rectangle GetM_exitButtonRect() {
        return m_exitButtonRect;
    }

    /**
     *
     * @return
     */
    public String GetM_message() {
        return m_message;
    }
    /**
     *
     * @param s the message that is shown on the screen while playing, describing the
     *          state of the game
     */
    public void SetGetM_message(String s){
        m_message = s;
    }

    /**
     *
     * @param m_restartButtonRect a button that when clicked restarts the game
     */
    public void SetM_restartButtonRect(Rectangle m_restartButtonRect) {
        this.m_restartButtonRect = m_restartButtonRect;
    }
    /**
     * sets the colour to a specific colour scheme
     */
    public void SetBG_COLOR(){
        if(m_isPink){
            BG_COLOR = Color.pink;
        }else{
            BG_COLOR = Color.cyan;
        }

    }

    /**
     *
     * @param m_exitButtonRect a button that when clicked exits the game
     */
    public void SetM_exitButtonRect(Rectangle m_exitButtonRect) {
        this.m_exitButtonRect = m_exitButtonRect;
    }
    public void SetM_strLen(int m_strLen) {
        this.m_strLen = m_strLen;
    }

    public int GetM_initialTime() {
        return m_initialTime;
    }
    public DebugConsoleController GetM_dcc() {
        return m_dcc;
    }
    public Font GetM_menuFont() {
        return m_menuFont;
    }

    public void SetM_menuFont(Font m_menuFont) {
        this.m_menuFont = m_menuFont;
    }

    /**
     *
     * @param m_wall
     */
    public void SetM_wall(Wall m_wall) {
        this.m_wall = m_wall;
    }

    /**
     *
     * @param m_debugConsole
     */
    public void SetM_debugConsole(DebugConsole m_debugConsole) {
        this.m_debugConsole = m_debugConsole;
    }

    public void SetM_clock(CountdownTimer m_clock) {
        this.m_clock = m_clock;
    }
    /**
     *
     * @param s a menu that appears when the game is paused, with options such as continue, exit and restart
     */
    public void SetM_showPauseMenu(boolean s){
        m_showPauseMenu = s;
    }


    /**
     *
     * @param isPink determines if the colour scheme is pink or not
     */
    public void SetPink(boolean isPink){
        m_isPink = isPink;
    }


    public void SetM_continueButtonRect(Rectangle m_continueButtonRect) {
        this.m_continueButtonRect = m_continueButtonRect;
    }


    public void SetM_dcc(DebugConsoleController m_dcc) {
        this.m_dcc = m_dcc;
    }

    public void SetM_message(String m_message) {
        this.m_message = m_message;
    }
    //add a jlabel with a score and with a clock

    /**
     * @param owner the frame that the game board belongs to
     */
    public GameBoard(JFrame owner) {
        super();

        SetM_strLen(0);
        SetM_showPauseMenu(false);

        SetM_menuFont(new Font("Monospaced", Font.PLAIN, TEXT_SIZE));

        this.Initialize();
        SetM_message("Press SPACE to start");
        SetM_wall(new Wall(new Rectangle(0, 0, DEF_WIDTH, DEF_HEIGHT), 30, 3, 6 / 2, new Point(300, 430)));

        SetM_debugConsole(new DebugConsole(owner, GetM_wall(), this));
        //change this to controller
        DebugConsoleController dcc = DebugConsoleController.DebugConsoleInstance(this);
        //SetM_dcc(new DebugConsoleController(this));
        SetM_dcc(dcc);
      //now start using controller
        //initialize the first level
        GetM_wall().nextLevel();

        m_gameTimer = new Timer(1, e -> {
            GetM_wall().move();
            GetM_wall().findImpacts();
            SetM_message(String.format("Bricks: %d Balls %d", GetM_wall().getM_brickCount(), GetM_wall().getM_ballCount()));
            if (GetM_wall().isM_ballLost()) {
                if (GetM_wall().ballEnd()) {
                    GetM_wall().wallReset();
                    SetM_message("Game over");
                }
                GetM_wall().ballReset();
                GetM_gameTimer().stop();
            } else if (GetM_wall().isDone()) {
                if (GetM_wall().hasLevel()) {
                    SetM_message("Go to Next Level. Your current score is: ");
                    GetM_wall().setPlayerScore();
                    JOptionPane.showMessageDialog(null, GetM_message() + GetM_wall().getM_score());
                    GetM_gameTimer().stop();
                    GetM_wall().ballReset();
                    GetM_wall().wallReset();
                    GetM_wall().nextLevel();
                } else {
                    SetM_message("ALL WALLS DESTROYED! Your final score is: ");
                    //write score to file
                    //popup with score
                    GetM_wall().setPlayerScore();
                    JOptionPane.showMessageDialog(null, GetM_message() + GetM_wall().getM_score());
                    GetM_gameTimer().stop();
                }
            }

            repaint();
        });
    }



    /**
     *
     * @param t the game timer which is needed to help the game perform repetitive tasks
     */
    public void SetM_gameTimer(Timer t){
        m_gameTimer = t;
    }



    /**
     *Initialises the game board variables
     */
    public void Initialize() {
        this.setPreferredSize(new Dimension(DEF_WIDTH, DEF_HEIGHT));
        this.setFocusable(true);
        this.requestFocusInWindow();

        GetM_clock().startCountdown(200);
    }

    /**
     *
     * @param g the graphics used to paint things onto the board
     */
    public void paint(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        Clear(g2d);
        g2d.setColor(Color.BLUE);
        g2d.drawString(GetM_message(), 250, 225);

        DrawBall(GetM_wall().GetBall(), g2d);

        for (Brick b : GetM_wall().GetBricks()){
            if (!b.IsBroken()) {
                DrawBrick(b, g2d);
            }
        }
        DrawPlayer(GetM_wall().GetPlayer(), g2d);
        if (GetM_showPauseMenu()){
            DrawMenu(g2d);
        }
        Toolkit.getDefaultToolkit().sync();
    }

    /**
     *This method makes the game timer start
     */
    public void StartTimer(){
        GetM_clock().startCountdown(GetM_initialTime());
    }

    /**
     * @param g2d the graphics used to clear the screen
     */
    public void Clear(Graphics2D g2d) {
        Color tmp = g2d.getColor();
        g2d.setColor(BG_COLOR);
        g2d.fillRect(0, 0, getWidth(), getHeight());
        g2d.setColor(tmp);
    }

    /**
     * @param brick a single brick used to build the game's wall
     * @param g2d the graphics used to draw the brick
     */
    public void DrawBrick(Brick brick, Graphics2D g2d) {
        Color tmp = g2d.getColor();

        g2d.setColor(brick.GetInnerColor());
        g2d.fill(brick.GetBrick());

        g2d.setColor(brick.GetBorderColor());
        g2d.draw(brick.GetBrick());


        g2d.setColor(tmp);
    }

    /**
     * @param ball the ball being used for this game
     * @param g2d the graphics used to draw the ball on the screen
     */
    public void DrawBall(Ball ball, Graphics2D g2d) {
        Color tmp = g2d.getColor();

        Shape s = ball.GetBallFace();

        g2d.setColor(ball.GetInnerColor());
        g2d.fill(s);

        g2d.setColor(ball.GetBorderColor());
        g2d.draw(s);

        g2d.setColor(tmp);
    }

    /**
     * @param p the paddle controlled by the player, used to play the game
     * @param g2d the graphics used to draw the paddle
     */
    public void DrawPlayer(Paddle p, Graphics2D g2d) {
        Color tmp = g2d.getColor();

        Shape s = p.getM_paddleFace();
        g2d.setColor(p.GetInnerColor());
        g2d.fill(s);

        g2d.setColor(p.getBoarderColor());
        g2d.draw(s);

        g2d.setColor(tmp);
    }

    /**
     * @param g2d the graphics used to draw the menu
     */
    public void DrawMenu(Graphics2D g2d) {
        ObscureGameBoard(g2d);
        DrawPauseMenu(g2d);
    }

    /**
     * @param g2d the graphics used to draw the game board
     */
    public void ObscureGameBoard(Graphics2D g2d) {

        Composite tmp = g2d.getComposite();
        Color tmpColor = g2d.getColor();

        AlphaComposite ac = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.55f);
        g2d.setComposite(ac);

        g2d.setColor(Color.BLACK);
        g2d.fillRect(0, 0, DEF_WIDTH, DEF_HEIGHT);

        g2d.setComposite(tmp);
        g2d.setColor(tmpColor);
    }

    /**
     * @param g2d the graphics used to draw the menu that appears when paused
     */
    public void DrawPauseMenu(Graphics2D g2d) {
        Font tmpFont = g2d.getFont();
        Color tmpColor = g2d.getColor();


        g2d.setFont(GetM_menuFont());
        g2d.setColor(MENU_COLOR);

        if (GetM_strLen() == 0) {
            FontRenderContext frc = g2d.getFontRenderContext();
            SetM_strLen(GetM_menuFont().getStringBounds(PAUSE, frc).getBounds().width);
        }

        int x = (this.getWidth() - GetM_strLen()) / 2;
        int y = this.getHeight() / 10;

        g2d.drawString(PAUSE, x, y);

        x = this.getWidth() / 8;
        y = this.getHeight() / 4;


        if (GetM_continueButtonRect() == null) {
            FontRenderContext frc = g2d.getFontRenderContext();
            SetM_continueButtonRect(GetM_menuFont().getStringBounds(CONTINUE, frc).getBounds());
            GetM_continueButtonRect().setLocation(x, y - GetM_continueButtonRect().height);
        }

        g2d.drawString(CONTINUE, x, y);

        y *= 2;

        if (GetM_restartButtonRect() == null) {
            SetM_restartButtonRect((Rectangle) GetM_continueButtonRect().clone());
            GetM_restartButtonRect().setLocation(x, y - GetM_restartButtonRect().height);
        }

        g2d.drawString(RESTART, x, y);

        y *= 3.0 / 2;

        if (GetM_exitButtonRect() == null) {
            SetM_exitButtonRect((Rectangle) GetM_continueButtonRect().clone());
            GetM_exitButtonRect().setLocation(x, y - GetM_exitButtonRect().height);
        }

        g2d.drawString(EXIT, x, y);


        g2d.setFont(tmpFont);
        g2d.setColor(tmpColor);
    }




    /**
     *this function makes the game timer stop and the game pause when the player clicks outside the window.
     */
    public void OnLostFocus() {
        GetM_gameTimer().stop();
        SetM_message("Focus Lost");
        repaint();
    }

}

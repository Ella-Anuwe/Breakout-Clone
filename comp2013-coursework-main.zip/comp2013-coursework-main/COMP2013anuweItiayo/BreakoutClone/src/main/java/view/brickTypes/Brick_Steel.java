package view.brickTypes;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Random;

/**
 *This class creates a brick with a 40% chance of being destroyed when hit
 * Changes:
 * 1. Changing the names of variables
 */
public class Brick_Steel extends Brick {

    private static final Color DEF_INNER = new Color(203, 203, 201);
    private static final Color DEF_BORDER = Color.BLACK;
    private static final int STEEL_STRENGTH = 1;
    private static final double STEEL_PROBABILITY = 0.4;
    private Random m_rnd;
    private Shape m_brickFace;

    /**
     * @param point the pint on the screen containing the brick
     * @param size the width and height of the brick
     */
    public Brick_Steel(Point point, Dimension size) {
        super(point, size, DEF_BORDER, DEF_INNER, STEEL_STRENGTH);
        m_rnd = new Random();
        m_brickFace = super.GetBrickFace();
    }


    /**
     * @param pos the location of the new feature
     * @param size the width and height of the brick's face
     * @return a shape of the width and height of the brick
     */
    @Override
    protected Shape MakeBrickFace(Point pos, Dimension size) {
        return new Rectangle(pos, size);
    }

    /**
     * @return returns a shape which represents the area which is the brick
     */
    @Override
    public Shape GetBrick() {
        return m_brickFace;
    }

    /**
     *
     * @param brick the bricks used to build the game
     */
    @Override
    public void SetBrick(Shape brick) {

    }

    /**
     * @param point the position of the brick/ball impact
     * @param dir the direction of the ball when it made impact with the brick
     * @return true if the brick isn't broken, and false if the brick is broken
     */
    public boolean SetImpact(Point2D point, int dir) {
        if (super.IsBroken())
            return false;
        Impact();
        return super.IsBroken();
    }

    /**
     * When the ball makes impact with the brick, the brick might be destroyed
     * if the random integer generated is less than the probability if of the steel brick
     * breaking
     */
    public void Impact() {
        if (m_rnd.nextDouble() < STEEL_PROBABILITY) {
            super.Impact();
        }
    }

}

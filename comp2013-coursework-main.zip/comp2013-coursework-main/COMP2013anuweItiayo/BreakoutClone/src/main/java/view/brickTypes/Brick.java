package view.brickTypes;

import view.ballTypes.Ball;

import java.awt.*;
import java.awt.geom.Point2D;

/**
 * Programing conventions that have been violated:
 * 1. Methods do not have tags
 * 2. Member variables are public - need to be made
 * private, and given getters (no setters because they are final)
 * 3. Order of variables and methods wrong
 * 4. Switch case changed to an if statement
 * 5. Name parameter removed from brick constructor and as a member variable due to being unnecessary
 */
abstract public class Brick {

    //made private and given getters
    private final int MAX_CRACK = 3;
    private final int DEF_CRACK_DEPTH = 1;
    private final int DEF_STEPS = 35;

    private final int UP_IMPACT = 100;
    private final int DOWN_IMPACT = 200;
    private final int LEFT_IMPACT = 300;
    private final int RIGHT_IMPACT = 400;

    private Shape m_brickFace;

    private Color m_border;
    private Color m_inner;

    private int m_fullStrength;
    private int m_strength;

    private boolean m_broken;

    /**
     * @return the area representing each brick, which helps the
     * game determine if the ball impacts the area encapsulated
     * by the brick's coordinates.
     */
    public Shape GetBrickFace() {
        return m_brickFace;
    }

    /**
     * @return the maximum number of cracks a brick can get before it
     * is destroyed
     */
    public int GetMaxCrack() {
        return MAX_CRACK;
    }

//    /**
//     * @return the
//     */
//    public int GetMinCrack() {
//        return MIN_CRACK;
//    }

//    /**
//     * @return
//     */
//    public int GetDefCrackDepth() {
//        return DEF_CRACK_DEPTH;
//    }

    /**
     * @return
     */
    public int GetDefSteps() {
        return DEF_STEPS;
    }


    /**
     * @return
     */
    public final int GetUpImpact() {
        return UP_IMPACT;
    }

    /**
     * @return
     */
    public final int GetDownImpact() {
        return DOWN_IMPACT;
    }

    /**
     * @return
     */
    public final int GetRightImpact() {
        return RIGHT_IMPACT;
    }

    /**
     * @return returns the impact made when the left side is hit?
     */
    public final int GetLeftImpact() {
        return LEFT_IMPACT;
    }


    /**
     * @param pos the coordinates of the brick
     * @param size the size of the brick
     * @param border the colour of the brick's boarder
     * @param inner the inner colour of the brick
     * @param strength the strength of the brick (
     */
    public Brick(Point pos, Dimension size, Color border, Color inner, int strength) {
        //name var has been removed
        m_broken = false;
        m_brickFace = MakeBrickFace(pos, size);
        this.m_border = border;
        this.m_inner = inner;
        this.m_fullStrength = this.m_strength = strength;

    }


    /**
     * @param pos
     * @param size
     * @return
     */
    protected abstract Shape MakeBrickFace(Point pos, Dimension size);

    /**
     * @param point
     * @param dir
     * @return
     */
    public boolean SetImpact(Point2D point, int dir) {
        if (m_broken)
            return false;
        Impact();
        return m_broken;
    }

    /**
     * @return
     */
    public abstract Shape GetBrick();

    /**
     * @return
     */
    public abstract void SetBrick(Shape brick);

    /**
     * @return
     */
    public Color GetBorderColor() {
        return m_border;
    }

    /**
     * @return
     */
    public Color GetInnerColor() {
        return m_inner;
    }

    /**
     * @param b finds out if the ball has made impact with the brick or not
     * @return
     */
    public final int FindImpact(Ball b) {
        if (m_broken)
            return 0;
        int out = 0;
        if (m_brickFace.contains(b.GetRight()))
            out = LEFT_IMPACT;
        else if (m_brickFace.contains(b.GetLeft()))
            out = RIGHT_IMPACT;
        else if (m_brickFace.contains(b.GetUp()))
            out = DOWN_IMPACT;
        else if (m_brickFace.contains(b.GetDown()))
            out = UP_IMPACT;
        return out;
    }

    /**
     * @return returns a boolean representing if the brick is broken or not
     */
    public final boolean IsBroken() {
        return m_broken;
    }

    /**
     * Repairs the brick, removing all cracks and restoring its strength as if
     * it had never been impacted to begin with
     */
    public void Repair() {
        m_broken = false;
        m_strength = m_fullStrength;
    }

    /**
     * This method determines what happens when the ball makes impact with a brick
     */
    public void Impact() {
        m_strength--;
        m_broken = (m_strength == 0);
    }
}
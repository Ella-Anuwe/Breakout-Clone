package view.gameequipment;

import view.ballTypes.Ball;

import java.awt.*;

/**
 * This class is responsible for the paddle that moves across the bottom of the screen.
 */

/**
 * Programing conventions that have been violated:
 * 1. Removed static variables
 */
public class Paddle {
    private static final Color m_BORDER_COLOR = Color.GREEN.darker().darker();
    private static final Color m_INNER_COLOR = Color.BLACK;
    private static final int m_DEF_MOVE_AMOUNT = 5;

    private int m_score;
    private Rectangle m_paddleFace;
    private Point m_ballPoint;
    private int m_moveAmount;
    private int m_min;
    private int m_max;
    //getters

    /**
     *
     * @return the current score of the player
     */
    public int GetScore() {
        return m_score;
    }

    /**
     * @return the inner colour of the paddle
     */
    public Color GetInnerColor() {
        return m_INNER_COLOR;
    }

    /**
     *
     * @param m_score the score of the player
     */
    public void setM_score(int m_score) {
        this.m_score = m_score;
    }
//    public void incrementScore() {
//        this.score++;
//    }
    /**
     * @return the colour of the boarder of the paddle
     */
    public Color getBoarderColor() {
        return m_BORDER_COLOR;
    }

    /**
     * @param ballPoint the position of the ball
     * @param width the width of the ball
     * @param height the height of the ball
     * @param container the type of shape used to specify its bounds/area it covers
     */
    public Paddle(Point ballPoint, int width, int height, Rectangle container) {
        this.m_ballPoint = ballPoint;
        m_moveAmount = 0;
        m_paddleFace = makeRectangle(width, height);
        m_min = container.x + (width / 2);
        m_max = m_min + container.width - width;
       // setPlayerColor();
    }

//    public void setPlayerColor(){
//        if(isPink){
//            INNER_COLOR = Color.GRAY;
//        }else{
//            INNER_COLOR = Color.BLACK;
//        }
//
//    }


    /**
     * @param width the horizontal length of the paddle
     * @param height the vertical length of the paddle
     * @return a rectangle with set dimensions and position
     */
    public Rectangle makeRectangle(int width, int height) {
        Point p = new Point((int) (m_ballPoint.getX() - (width / 2)), (int) m_ballPoint.getY());
        return new Rectangle(p, new Dimension(width, height));
    }

    /**
     * @param b the ball being used in this game
     * @return true if the ball has mde impact, false if it hasn't
     */
    public boolean impact(Ball b) {
        return m_paddleFace.contains(b.GetBallPosition()) && m_paddleFace.contains(b.GetDown());
    }

    /**
     * moves the paddle based on the inputs from the keyboard
     */
    public void move() {
        double x = m_ballPoint.getX() + m_moveAmount;
        if (x < m_min || x > m_max)
            return;
        m_ballPoint.setLocation(x, m_ballPoint.getY());
        m_paddleFace.setLocation(m_ballPoint.x - (int) m_paddleFace.getWidth() / 2, m_ballPoint.y);
    }

    /**
     *Moves the player's paddle to the left
     */
    public void moveLeft() {
        m_moveAmount = -m_DEF_MOVE_AMOUNT;
    }

    /**
     *Moves the player's paddle to the right
     */
    public void movRight() {
        m_moveAmount = m_DEF_MOVE_AMOUNT;
    }

    /**
     *Stops the paddle from moving
     */
    public void stop() {
        m_moveAmount = 0;
    }

    /**
     * @return a shape which represents the area the paddle is contained in, with dimensions and a position
     */
    public Shape getM_paddleFace() {
        return m_paddleFace;
    }

    /**
     * @param p the point that the player's paddle is going to be moved to
     */
    public void moveTo(Point p) {
        m_ballPoint.setLocation(p);
        m_paddleFace.setLocation(m_ballPoint.x - (int) m_paddleFace.getWidth() / 2, m_ballPoint.y);
    }


}

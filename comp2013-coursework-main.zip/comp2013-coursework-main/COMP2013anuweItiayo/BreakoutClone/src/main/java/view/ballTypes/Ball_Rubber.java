package view.ballTypes;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

/**
 * This class contains the code for a rubber ball
 * Changes:
 * 1. Removed the unnecessary name variable
 * 2. Renamed the class to something more descriptive
 * 3. Privatised and renamed variables
 *
 */
public class Ball_Rubber extends Ball {

    private static int m_radius = 10;
    private static Color m_innerColor = new Color(255, 219, 88);
    private static Color m_boarderColor = m_innerColor.darker().darker();
    int m = 10;
    /**
     * this constructor creates a rubber ball object with starting coordinates, a radius, inner colour and
     * boarder colour
     * @param center the coordinates of the center of the ball
     */
    public Ball_Rubber(Point2D center) {
        super(center, m_radius, m_radius, m_innerColor, m_boarderColor);
    }

    /**
     * @param center coordinates of the center of the ball
     * @param radiusA radius of ball along x-axis
     * @param radiusB radius of ball along y-axis
     * @return a shape object which is the shape of the ball
     */
    @Override
    protected Shape MakeBall(Point2D center, int radiusA, int radiusB) {

        double x = center.getX() - (radiusA / 2);
        double y = center.getY() - (radiusB / 2);

        return new Ellipse2D.Double(x, y, radiusA, radiusB);
    }
}

package view.gameequipment;


import javafx.scene.control.Label;
import java.util.Timer;
import java.util.TimerTask;

/**
 * This class is used in one of the levels to give the player a time limit while they're playing
 */
//perhaps timer can be for new level with 2 balls, and timer stops when balls are both gone
public class CountdownTimer extends Label {

    private int secondsPassed = 0;
    private Timer myTimer = new Timer();
    //when level is started this needs to be set
    private int limit;
    private boolean startClock = false;

    public TimerTask getTask() {
        return task;
    }

    public void setTask(TimerTask task) {
        this.task = task;
    }

    public boolean isStartClock() {
        return startClock;
    }

    public void setStartClock(boolean startClock) {
        this.startClock = startClock;
    }

    public Timer getMyTimer() {
        return myTimer;
    }

    public void setMyTimer(Timer myTimer) {
        this.myTimer = myTimer;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getSecondsPassed() {
        return secondsPassed;
    }

    public void setSecondsPassed(int secondsPassed) {
        this.secondsPassed = secondsPassed;
    }

    /**
     * This function is used to start the countdown
     * @param lim needs to be given a limit so that the timer can start
     */
    public void startCountdown(int lim){
        this.startClock = true;
        this.limit = lim;
        start();
    }
    /**
     *
     */
    private TimerTask task = new TimerTask() {
        @Override
        public void run() {
            int i = 0;
            while( (i< limit) && (startClock == true)){
                secondsPassed++;
                //timer displays the remaining time
                setText(""+ (limit-secondsPassed));
                i++;
            }
        }
    };

    /**
     * This is the function used to start the timer and specify how long it will run for and
     * how fast it will go
     */
    public void start(){
        myTimer.scheduleAtFixedRate(task, 1000, 1000);
    }

    /**
     * This starts the timer again from 0
     */
    public void resetTimer(){
        startClock = false;
        secondsPassed = 0;
    }

    /**
     *
     * @param timeLimit this is an integer passed into the constructor to determine how
     * long the clock will run for
     */
//    public CountdownTimer(int timeLimit){
//        this.limit = timeLimit;
//    }

}

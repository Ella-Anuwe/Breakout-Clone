package view.gameinterface;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;


public class GameFrame extends JFrame implements WindowFocusListener {

    //was public, now private. needs getters and setters
    private final String DEF_TITLE = "Breakout Clone     space = start/pause   ←/→ = move left/right   esc = menu";
    private GameBoard m_gameBoard;
    private boolean m_gaming;

    /**
     *
     * @param gameBoard
     */
    public void SetGameBoard(GameBoard gameBoard) {
        this.m_gameBoard = gameBoard;
    }

    /**
     *
     * @return
     */
    public GameBoard SetGameBoard() {
        return m_gameBoard;
    }

    /**
     * @return
     */
    public String SetDefTitle() {
        return DEF_TITLE;
    }

    /**
     *
     * @return
     */
    public boolean GetGaming(){
        return m_gaming;
    }

    /**
     *
     * @param g
     */
    public void SetGaming(boolean g){
        this.m_gaming = g;
    }

    /**
     *
     * @return
     */
    public GameBoard GetM_gameBoard() {
        return m_gameBoard;
    }

    /**
     *
     * @param m_gameBoard
     */
    public void SetM_gameBoard(GameBoard m_gameBoard) {
        this.m_gameBoard = m_gameBoard;
    }

    /**
     *
     * @return
     */
    public boolean IsM_gaming() {
        return m_gaming;
    }

    /**
     *
     * @param m_gaming
     */
    public void SetM_gaming(boolean m_gaming) {
        this.m_gaming = m_gaming;
    }

    /**
     *
     * @param isPink
     */
    public GameFrame(boolean isPink){
        //set everything to pink mode
        super();

        SetM_gaming(false);
        this.setLayout(new BorderLayout());
        SetM_gameBoard(new GameBoard(this));
        GetM_gameBoard().SetPink(isPink);
        GetM_gameBoard().SetBG_COLOR();
        //making things pink
        this.add(GetM_gameBoard(), BorderLayout.CENTER);
        Initialize();
        this.addWindowFocusListener(this);
    }

    /**
     *
     */
    public void Initialize() {
        this.setTitle(DEF_TITLE);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        this.AutoLocate();
        this.setVisible(true);
    }

    /**
     *
     */
    public void AutoLocate() {
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (size.width - this.getWidth()) / 2;
        int y = (size.height - this.getHeight()) / 2;
        this.setLocation(x, y);
    }

    /**
     * @param windowEvent an event that indicates the window's status has changed
     */
    @Override
    public void windowLostFocus(WindowEvent windowEvent) {
        if (this.GetGaming())
            GetM_gameBoard().OnLostFocus();

    }

    /**
     * @param windowEvent
     */
    @Override
    public void windowGainedFocus(WindowEvent windowEvent) {
        // the first time the frame loses focus is because it has been disposed to install the GameBoard, so went it regains the focus it's ready to play. of course calling a method such as 'onLostFocus' is useful only if the GameBoard as been displayed at least once
        this.SetGaming(true);
    }

}

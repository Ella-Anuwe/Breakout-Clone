package view.brickTypes;

import java.awt.*;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;

/**
 * This class represents a specific type of brick used in the second level.
 *
 */
public class Brick_Cement extends Brick {

    private static final Color DEF_INNER = new Color(147, 147, 147);
    private static final Color DEF_BORDER = new Color(217, 199, 175);
    private static final int CEMENT_STRENGTH = 2;

    private Crack crack;
    private Shape brickFace;

    /**
     * @param point the position of the brick on the screen
     * @param size the size of the brick (size of area encapsulated by width and height)
     */
    public Brick_Cement(Point point, Dimension size) {
        super(point, size, DEF_BORDER, DEF_INNER, CEMENT_STRENGTH);
        brickFace = super.GetBrickFace();
        crack = new Crack(GetMaxCrack(), GetDefSteps(), brickFace);
    }

    /**
     * @param pos the position of the brick face
     * @param size the size of the brick (size of area encapsulated by width and height)
     * @return returns a shape which is the dimensions of the prick and its location: the
     * area it encapsulates determined by its height and width and where it is in terms of
     * coordinates
     */
    @Override
    protected Shape MakeBrickFace(Point pos, Dimension size) {
        return new Rectangle(pos, size);
    }

    /**
     * @param point the position where the brick has been impacted
     * @param dir the direction of the crack
     * @return if it's already broken, return false. else, a crack is made and
     * the brick's appearance is updated. returns true after
     */
    @Override
    public boolean SetImpact(Point2D point, int dir) {
        if (super.IsBroken())
            return false;
        super.Impact();
        if (!super.IsBroken()) {
            crack.makeCrack(point, dir);
            updateBrick();
            return false;
        }
        return true;
    }

    /**
     * @return returns a shape object representing the area that is the brick
     */
    @Override
    public Shape GetBrick() {
        return brickFace;
    }

    //was private, now public

    /**
     *
     * @param brick
     */
    @Override
    public void SetBrick(Shape brick) {
        this.brickFace = brick;
    }
    /**
     *If the brick isn't broken, a line is created which is the crack and this is
     * added to the brick's face.
     */
    public void updateBrick() {
        if (!super.IsBroken()) {
            GeneralPath gp = crack.draw();
            gp.append(super.GetBrickFace(), false);
            brickFace = gp;
        }
    }

    /**
     *This removes any cracks from the brick
     */
    public void Repair() {
        super.Repair();
        crack.reset();
        SetBrick(super.GetBrickFace());
    }
}

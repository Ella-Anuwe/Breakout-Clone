package view.gameequipment;

import view.ballTypes.Ball;
import view.ballTypes.Ball_Rubber;
import view.brickTypes.*;

import java.awt.*;
import java.awt.geom.Point2D;
import java.util.Random;

/**
 * this class is responsible for the wall of bricks seen at
 * the top of the screen. Depending on the level, there will
 * be different types of bricks in different places
 *
 * Changes made:
 * 1. Added method tags
 */

/**
 * Programing conventions that have been violated:
 * 1. Methods do not have tags
 */
//do constructors need return tags?

/**
 * The class wall contains variables for the types of bricks,
 * the level that the player is on, the array containing the bricks, and
 * the other objects on the screen such as the ball and the paddle controlled
 * Changes made:
 * 1. method names begin with capital letter
 * 2. member variables begin with m_
 * 3. No variables are static
 */
public class Wall {

    private Rectangle m_area;
    private Ball m_ball;
    private int m_ballCount;
    private boolean m_ballLost;
    private Brick[] m_bricks;
    private int m_brickCount;
    private final int CEMENT = 3;
    private final int CLAY = 1;
    private int m_level;
    private Brick[][] m_levels;
    private final int LEVELS_COUNT = 4;
    private Paddle m_player;
    private Point m_startPoint;
    private final int STEEL = 2;
    private Random m_rnd;
    private int m_score;

    /**
     *
     * @return
     */
    public int getM_score() {
        return m_score;
    }

    /**
     *
     * @param s
     */
    public void setM_score(int s){
        this.m_score = s;
    }

    /**
     *
     */
    public void incrementScore(){
        this.m_score++;
    }

    /**
     *
     */
    public void setPlayerScore() {
        m_player.setM_score(this.m_score);
    }

    /**
     *
     * @return
     */
    public Ball GetBall() {
        return m_ball;
    }

    /**
     *
     * @return
     */
    public Paddle GetPlayer() {
        return m_player;
    }

    /**
     *
     * @return
     */
    public Brick[] GetBricks() {
        return m_bricks;
    }

    /**
     * @param drawArea
     * @param brickCount the number of bricks
     * @param lineCount
     * @param brickDimensionRatio
     * @param ballPos
     */
    public Wall(Rectangle drawArea, int brickCount, int lineCount, double brickDimensionRatio, Point ballPos) {

        this.m_startPoint = new Point(ballPos);

        m_levels = makeLevels(drawArea, brickCount, lineCount, brickDimensionRatio);
        m_level = 0;

        m_ballCount = 3;
        m_ballLost = false;

        m_rnd = new Random();

        makeBall(ballPos);
        //why is this here? is it okay to remove?
        //what it does is understood:
        int speedX, speedY;
        do {
            speedX = m_rnd.nextInt(3) - 2;
        } while (speedX == 0);
        do {
            speedY = -m_rnd.nextInt(3);
        } while (speedY == 0);

        m_ball.SetBallSpeed(speedX, speedY);

        m_player = new Paddle((Point) ballPos.clone(), 150, 10, drawArea);
        m_area = drawArea;
    }

    /**
     * @param drawArea an object of the Rectangle class which is used to make up the bricks in the game
     * @param brickCnt an integer variable representing the number of bricks needed on the screen
     * @param lineCnt an integer with the number of lines of bricks there are
     * @param brickSizeRatio used to calculate the height and width of the bricks in relation to the size of the screen
     * @param type the type of brick e.g. cement, clay, ext.
     */
    //inherit
    public Brick[] makeSingleTypeLevel(Rectangle drawArea, int brickCnt, int lineCnt, double brickSizeRatio, int type){
        // if brickCount is not divisible by line count,brickCount is adjusted to the biggest multiple of lineCount smaller then brickCount
        brickCnt -= brickCnt % lineCnt;

        int brickOnLine = brickCnt / lineCnt;

        double brickLen = drawArea.getWidth() / brickOnLine;
        double brickHgt = brickLen / brickSizeRatio;

        brickCnt += lineCnt / 2;

        Brick[] tmp  = new Brick[brickCnt];

        Dimension brickSize = new Dimension((int) brickLen,(int) brickHgt);
        Point p = new Point();

        int i;
        for(i = 0; i < tmp.length; i++){
            int line = i / brickOnLine;
            if(line == lineCnt)
                break;
            double x = (i % brickOnLine) * brickLen;
            x =(line % 2 == 0) ? x : (x - (brickLen / 2));
            double y = (line) * brickHgt;
            p.setLocation(x,y);
            tmp[i] = makeBrick(p,brickSize,type);
        }

        for(double y = brickHgt;i < tmp.length;i++, y += 2*brickHgt){
            double x = (brickOnLine * brickLen) - (brickLen / 2);
            p.setLocation(x,y);
            tmp[i] = new Brick_Clay(p,brickSize);
        }
        return tmp;

    }

    /**
     *
     * @param drawArea
     * @param brickCnt
     * @param lineCnt
     * @param brickSizeRatio
     * @param typeA
     * @param typeB
     * @return
     */
    public Brick[] makeChessboardLevel(Rectangle drawArea, int brickCnt, int lineCnt, double brickSizeRatio, int typeA, int typeB){
        // if brickCount is not divisible by line count, brickCount is adjusted to the biggest multiple of lineCount smaller then brickCount
        brickCnt -= brickCnt % lineCnt;

        int brickOnLine = brickCnt / lineCnt;

        int centerLeft = brickOnLine / 2 - 1;
        int centerRight = brickOnLine / 2 + 1;

        double brickLen = drawArea.getWidth() / brickOnLine;
        double brickHgt = brickLen / brickSizeRatio;

        brickCnt += lineCnt / 2;

        Brick[] tmp  = new Brick[brickCnt];

        Dimension brickSize = new Dimension((int) brickLen,(int) brickHgt);
        Point p = new Point();

        int i;
        for(i = 0; i < tmp.length; i++){
            int line = i / brickOnLine;
            if(line == lineCnt)
                break;
            int posX = i % brickOnLine;
            double x = posX * brickLen;
            x =(line % 2 == 0) ? x : (x - (brickLen / 2));
            double y = (line) * brickHgt;
            p.setLocation(x,y);

            boolean b = ((line % 2 == 0 && i % 2 == 0) || (line % 2 != 0 && posX > centerLeft && posX <= centerRight));
            tmp[i] = b ?  makeBrick(p,brickSize,typeA) : makeBrick(p,brickSize,typeB);
        }

        for(double y = brickHgt;i < tmp.length;i++, y += 2*brickHgt){
            double x = (brickOnLine * brickLen) - (brickLen / 2);
            p.setLocation(x,y);
            tmp[i] = makeBrick(p,brickSize,typeA);
        }
        return tmp;
    }


    /**
     *
     * @param ballPos
     */
    public void makeBall(Point2D ballPos) {
        m_ball = new Ball_Rubber(ballPos);
    }

    /**
     *
     * @param drawArea
     * @param brickCount
     * @param lineCount
     * @param brickDimensionRatio
     * @return
     */
    public Brick[][] makeLevels(Rectangle drawArea, int brickCount, int lineCount, double brickDimensionRatio) {
        Brick[][] tmp = new Brick[LEVELS_COUNT][];
        tmp[0] = makeSingleTypeLevel(drawArea, brickCount, lineCount, brickDimensionRatio, CLAY);
        tmp[1] = makeChessboardLevel(drawArea, brickCount, lineCount, brickDimensionRatio, CLAY, CEMENT);
        tmp[2] = makeChessboardLevel(drawArea, brickCount, lineCount, brickDimensionRatio, CLAY, STEEL);
        tmp[3] = makeChessboardLevel(drawArea, brickCount, lineCount, brickDimensionRatio, STEEL, CEMENT);
        return tmp;
    }

    /**
     *
     */
    public void move() {
        m_player.move();
        m_ball.MoveBall();
    }

    /**
     *
     */
    public void findImpacts() {
        if (m_player.impact(m_ball)) {
            m_ball.ReverseY();
        } else if (impactWall()) {
            // for efficiency reverse is done into method impactWall because for every brick program checks for horizontal and vertical impacts
            m_brickCount--;
            m_score++;
        } else if (impactBorder()) {
            m_ball.ReverseX();
        } else if (m_ball.GetBallPosition().getY() < m_area.getY()) {
            m_ball.ReverseY();
        } else if (m_ball.GetBallPosition().getY() > m_area.getY() + m_area.getHeight()) {
            m_ballCount--;
            m_ballLost = true;
        }
    }

    /**
     * @return
     */
    public boolean impactWall() {
        int i;

        for (Brick b : m_bricks) {
            if (b.FindImpact(m_ball) == b.GetUpImpact()) {
                m_ball.ReverseY();
                return b.SetImpact(m_ball.GetDown(), Crack.UP);
            } else if (b.FindImpact(m_ball) == b.GetDownImpact()) {
                m_ball.ReverseY();
                return b.SetImpact(m_ball.GetUp(), Crack.DOWN);
            } else if (b.FindImpact(m_ball) == b.GetLeftImpact()) {
                m_ball.ReverseX();
                return b.SetImpact(m_ball.GetRight(), Crack.LEFT);
            } else if (b.FindImpact(m_ball) == b.GetRightImpact()) {
                m_ball.ReverseX();
                return b.SetImpact(m_ball.GetLeft(), Crack.RIGHT);
            }
        }
        return false;
    }

    /**
     * @return
     */
    public boolean impactBorder() {
        Point2D p = m_ball.GetBallPosition();
        return ((p.getX() < m_area.getX()) || (p.getX() > (m_area.getX() + m_area.getWidth())));
    }

    /**
     *
     * @return
     */
    public int getM_brickCount() {
        return m_brickCount;
    }

    /**
     *
     * @return
     */
    public int getM_ballCount() {
        return m_ballCount;
    }

    /**
     *
     * @return
     */
    public boolean isM_ballLost() {
        return m_ballLost;
    }

    /**
     *
     */
    public void ballReset() {
        m_player.moveTo(m_startPoint);
        m_ball.MoveTo(m_startPoint);
        int speedX, speedY;
        do {
            speedX = m_rnd.nextInt(5) - 2;
        } while (speedX == 0);
        do {
            speedY = -m_rnd.nextInt(3);
        } while (speedY == 0);

        m_ball.SetBallSpeed(speedX, speedY);
        m_ballLost = false;
    }

    /**
     *
     */
    public void wallReset() {
        for (Brick b : m_bricks)
            b.Repair();
        m_brickCount = m_bricks.length;
        m_ballCount = 3;
    }

    /**
     *
     * @return
     */
    public boolean ballEnd() {
        return m_ballCount == 0;
    }

    /**
     *
     * @return
     */
    public boolean isDone() {
        return m_brickCount == 0;
    }

    /**
     *
     */
    public void nextLevel() {
        m_bricks = m_levels[m_level++];
        this.m_brickCount = m_bricks.length;
    }

    /**
     * @return
     */
    public boolean hasLevel() {
        return m_level < m_levels.length;
    }

    /**
     * @param s the speed of the ball
     */
    public void setBallXSpeed(int s) {
        m_ball.SetXSpeed(s);
    }

    /**
     *
     * @param s
     */
    public void setBallYSpeed(int s) {
        m_ball.SetYSpeed(s);
    }

    /**
     *
     */
    public void resetBallCount() {
        m_ballCount = 3;
    }

    /**
     * @param point
     * @param size
     * @param type
     * @return
     */
    public Brick makeBrick(Point point, Dimension size, int type) {
        Brick out;
        switch (type) {
            case CLAY:
                out = new Brick_Clay(point, size);
                break;
            case STEEL:
                out = new Brick_Steel(point, size);
                break;
            case CEMENT:
                out = new Brick_Cement(point, size);
                break;
            default:
                throw new IllegalArgumentException(String.format("Unknown Type:%d\n", type));
        }
        return out;
    }

}
//check for repeated blocks of code
package view.ballTypes;

import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.RectangularShape;
//is 2 a magic number?
/**
 * This class is the basic template for a ball in this game.
 * It contains objects and variables symbolising the location
 * of the ball in coordinate space and the speed at which it is
 * going, and its direction.
 */

/**
 * changes:
 * 1.Privatising
 * 2. Making names begin with m_ and making public methods start with an uppercase
 *
 */
abstract public class Ball {
//do objects need to be named with m_?

    //variables and objects
    private Shape m_ballFace;
    private Color m_Border;
    private Point2D m_center;
    private Point2D m_down;
    private Color m_inner;
    private Point2D m_left;
    private Point2D m_right;
    private int m_speedX;
    private int m_speedY;
    private Point2D m_up;


    //getters

    /**
     * @return the speed of the ball along the x-axis
     */
    public int GetM_speedX() {
        return m_speedX;
    }

    /**
     * @return the coordinate above the ball
     */
    public Point2D GetUp() {
        return m_up;
    }

    /**
     * @return the coordinate below the ball
     */
    public Point2D GetDown() {
        return m_down;
    }

    /**
     * @return the coordinate left to the ball
     */
    public Point2D GetLeft() {
        return m_left;
    }

    /**
     * @return the coordinate to the right of the ball
     */
    public Point2D GetRight() {
        return m_right;
    }

    /**
     * @return the speed of the ball along the y-axis
     */
    public int GetM_speedY() {
        return m_speedY;
    }

    /**
     * @return the colour of the boarder of the ball
     */
    public Color GetBorderColor() {
        return m_Border;
    }

    /**
     *
     * @return
     */
    public Shape GetM_ballFace() {
        return m_ballFace;
    }

    /**
     * @return the inner colour of the ball
     */
    public Color GetInnerColor() {
        return m_inner;
    }

    /**
     * @return coordinates of the centre of the ball
     */
    public Point2D GetBallPosition() {
        return m_center;
    }

    /**
     * @return the face of the ball - aka the area that the ball is encapsulated in
     */
    public Shape GetBallFace() {
        return m_ballFace;
    }

    public Point2D GetM_center() {
        return m_center;
    }

    //setters

    public void SetM_up(Point2D up) {
        this.m_up = up;
    }

    public void SetM_down(Point2D down) {
        this.m_down = down;
    }

    public void SetM_left(Point2D left) {
        this.m_left = left;
    }

    public void SetM_right(Point2D right) {
        this.m_right = right;
    }

public void SetM_center(Point2D center){
        this.m_center = center;
}

    public void SetM_ballFace(Shape ballFace) {
        this.m_ballFace = ballFace;
    }

    /**
     * @param x the speed of the ball along the x-axis
     * @param y the speed of the ball along the y-axis
     */
    public void SetBallSpeed(int x, int y) {
        m_speedX = x;
        m_speedY = y;
    }

    /**
     * @param s the speed of the ball along the x-axis
     */
    public void SetXSpeed(int s) {
        m_speedX = s;
    }

    /**
     * @param s the speed of the ball along the y-axis
     */
    public void SetYSpeed(int s) {
        m_speedY = s;
    }

    /**
     * setting the location of the ball, taking into account its width and height
     * @param width the width of the ball
     * @param height the height of the ball
     */
    public void SetPoints(double width, double height) {
        GetUp().setLocation(GetM_center().getX(), GetM_center().getY() - (height / 2));
        GetDown().setLocation(GetM_center().getX(), GetM_center().getY() + (height / 2));

        GetLeft().setLocation(GetM_center().getX() - (width / 2), GetM_center().getY());
        GetRight().setLocation(GetM_center().getX() + (width / 2), GetM_center().getY());
    }

    //constructors

    /**
     * @param center the coordinates of the centre of the ball
     * @param radiusA half of the ball width
     * @param radiusB half of the ball height
     * @param inner the inner colour of the ball
     * @param border the border colour of the ball
     */
    //at upper limit of paramerers!
    public Ball(Point2D center, int radiusA, int radiusB, Color inner, Color border) {
        SetM_center(center);

        SetM_up(new Point2D.Double());
        SetM_down(new Point2D.Double());
        SetM_left(new Point2D.Double());
        SetM_right(new Point2D.Double());

        GetUp().setLocation(center.getX(), center.getY() - (radiusB / 2));
        GetDown().setLocation(center.getX(), center.getY() + (radiusB / 2));

        GetLeft().setLocation(center.getX() - (radiusA / 2), center.getY());
        GetRight().setLocation(center.getX() + (radiusA / 2), center.getY());


        SetM_ballFace(MakeBall(center, radiusA, radiusB));
        this.m_Border = border;
        this.m_inner = inner;
        m_speedX = 0;
        m_speedY = 0;
    }

    /**
     * @param center the coordinates of the center of the ball
     * @param radiusA the width of the ball
     * @param radiusB the height of the ball
     * @return a round shape object, with a coordinates for it's center, its width and height
     */
    protected abstract Shape MakeBall(Point2D center, int radiusA, int radiusB);

    //other methods

    /**
     * Makes the ball move across the screen by changing the coordinates of the ball
     * and thereby changing its position on the screen.
     */
    public void MoveBall() {
        RectangularShape tmp = (RectangularShape) m_ballFace;
        m_center.setLocation((m_center.getX() + m_speedX), (m_center.getY() + m_speedY));
        double w = tmp.getWidth();
        double h = tmp.getHeight();

        tmp.setFrame((m_center.getX() - (w / 2)), (m_center.getY() - (h / 2)), w, h);
        SetPoints(w, h);
        m_ballFace = tmp;
    }

    /**
     *reverses the direction of the ball along the x-axis
     */
    public void ReverseX() {
        m_speedX *= -1;
    }

    /**
     * reverses the direction of the ball along the y-axis
     */
    public void ReverseY() {
        m_speedY *= -1;
    }

    /**
     * @param p the location of the centre of the ball
     */
    public void MoveTo(Point p) {
        m_center.setLocation(p);

        RectangularShape tmp = (RectangularShape) m_ballFace;
        double w = tmp.getWidth();
        double h = tmp.getHeight();

        tmp.setFrame((m_center.getX() - (w / 2)), (m_center.getY() - (h / 2)), w, h);
        m_ballFace = tmp;
    }

}

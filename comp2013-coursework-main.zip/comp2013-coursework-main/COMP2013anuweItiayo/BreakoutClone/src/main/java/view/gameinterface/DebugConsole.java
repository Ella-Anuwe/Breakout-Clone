package view.gameinterface;

import view.gameequipment.Wall;

import javax.swing.*;
import java.awt.*;

/**
 * The DebugConsole is a window that appears that allows the user to change settings for the game.
 * It contains the debug panel, which has different game control features that allow the user to do this
 */
public class DebugConsole extends JDialog{

    private final String m_TITLE = "Debug Console";
    private JFrame m_owner;
    private DebugPanel m_debugPanel;
    private GameBoard m_gameBoard;
    private Wall m_wall;

    /**
     *
     * @return the game board being used for the game
     */
    public GameBoard GetM_gameBoard() {
        return m_gameBoard;
    }

    /**
     *
     * @return the panel that contains all the debugging components
     */
    public DebugPanel GetM_debugPanel() {
        return m_debugPanel;
    }

    /**
     *
     * @return the wall which contains the bricks, the ball, and paddle ext.
     */
    public Wall GetM_wall() {
        return m_wall;
    }

    /**#
     *
     * @return the frame that contains the panel for debugging
     */
    public JFrame GetM_owner() {
        return m_owner;
    }

    /**
     *
     * @param m_wall the wall which contains the bricks, the ball, and paddle ext.
     */
    public void SetM_wall(Wall m_wall) {
        this.m_wall = m_wall;
    }


    /**
     *
     * @param m_gameBoard the game board being used for the game
     */
    public void SetM_gameBoard(GameBoard m_gameBoard) {
        this.m_gameBoard = m_gameBoard;
    }

    /**
     *
     * @param m_debugPanel the panel that contains all the debugging components
     */
    public void SetM_debugPanel(DebugPanel m_debugPanel) {
        this.m_debugPanel = m_debugPanel;
    }


    /**
     *
     * @param m_owner the Frame that comes up when the debug console that opens, containing
     *                the panel and debug components
     */
    public void SetM_owner(JFrame m_owner) {
        this.m_owner = m_owner;
    }

    /**
     * @param owner the Frame that comes up when the debug console that opens, containing
     *      *                the panel and debug components
     * @param wall the wall which contains the bricks, the ball, and paddle ext.
     * @param gameBoard the game board being used for the game
     */
    public DebugConsole(JFrame owner, Wall wall, GameBoard gameBoard) {
        SetM_wall(wall);
        SetM_owner(owner);
        SetM_gameBoard(gameBoard);
        Initialize();

        SetM_debugPanel(new DebugPanel(wall));
        this.add(GetM_debugPanel(), BorderLayout.CENTER);
        this.pack();
    }

    /**
     *Sets up de debug console correctly by initialising values
     */
    public void Initialize() {
        this.setModal(true);
        this.setTitle(m_TITLE);
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.setLayout(new BorderLayout());
        //this.addWindowListener(this);
        this.setFocusable(true);
    }

    /**
     *Places the console at a specific position on the game frame
     */
    public void SetLocation() {
        int x = ((GetM_owner().getWidth() - this.getWidth()) / 2) + GetM_owner().getX();
        int y = ((GetM_owner().getHeight() - this.getHeight()) / 2) + GetM_owner().getY();
        this.setLocation(x, y);
    }


}

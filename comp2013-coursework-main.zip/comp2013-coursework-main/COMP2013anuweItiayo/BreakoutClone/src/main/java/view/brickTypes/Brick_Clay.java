package view.brickTypes;

import java.awt.*;

/**
 * This class is responsible for creating clay bricks - the most basic type of
 * brick used in the first level
 * Changes: added javadocs comments
 */
public class Brick_Clay extends Brick {

    private static final Color DEF_INNER = new Color(178, 34, 34).darker();
    private static final Color DEF_BORDER = Color.GRAY;
    private static final int CLAY_STRENGTH = 1;

    /**
     * @param point the position of the brick on the screen
     * @param size the width and height of the brick
     */
    public Brick_Clay(Point point, Dimension size) {
        super(point, size, DEF_BORDER, DEF_INNER, CLAY_STRENGTH);
    }

    /**
     * @param pos the position of the brick face on the screen
     * @param size width and height of the brick face
     * @return a shape that has the position and dimensions of the brick being used
     */
    @Override
    protected Shape MakeBrickFace(Point pos, Dimension size) {
        return new Rectangle(pos, size);
    }

    /**
     * @return the brick face - contains the position, height and width
     */
    @Override
    public Shape GetBrick() {
        return super.GetBrickFace();
    }

    /**
     *
     * @param brick one of the bricks being used to make up the wall
     */
    @Override
    public void SetBrick(Shape brick) {

    }


}

package view.gameinterface;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ScoreboardApplication extends Application {
    /**
     * This method determines what happens when the scoreboard part of
     * the application starts
     * @param stage this is a type of window for javafx, which contains all the other
     * components on the screen
     * @throws IOException this ensures that failed or interrupted input or output operations
     * do not result in the program not running.
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(ScoreboardApplication.class.getResource("Scoreboard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Scoreboard");
        stage.setScene(scene);
        stage.show();
    }
}

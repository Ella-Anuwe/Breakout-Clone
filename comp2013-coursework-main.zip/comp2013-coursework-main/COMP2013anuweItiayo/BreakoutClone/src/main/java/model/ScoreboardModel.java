package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * this class is for handling oll of the data related with the scoreboard.
 * it reads from the CSV file and writes to it, ensuring that there is some
 * form of permanent memory in the application, allowing different user scores
 * to be compared to one another.
 *
 * It also ensures that what is being written to the file has been sanitised; for
 * example there should be no commas written into the file as this can interfere with file
 * reading. Also, only integers can be saved as a score and so on.
 */
//testing should go on for this class
//add email api
public class ScoreboardModel {
    int m_score;
    String m_playerName;

    //the controller should have reading and writing functions
    //for the csv file
    String m_file = "C:\\Desktop\\Second-year\\DMS\\DMS Coursework\\comp2013-coursework\\COMP2013anuweItiayo\\BreakoutClone\\src\\main\\resources\\scores.csv";
    //method lines should not be this long but is there an exception for file paths?
    BufferedReader m_reader = null;
    String m_line = "";

    /**
     *
     * @return the name of the current player
     */
    public String GetPlayerName() {
        return m_playerName;
    }

    /**
     *
     * @param m_playerName the name of the current player
     */
    public void SetPlayerName(String m_playerName) {
        this.m_playerName = m_playerName;
    }

    /**
     *
     * @return the score of the current player
     */
    public int GetScore() {
        return m_score;
    }

    /**
     *
     * @param m_score the score of the current player
     */
    public void SetScore(int m_score) {
        this.m_score = m_score;
    }

    /**
     * This method reads from the CSV file containing the scores
     * @throws IOException a general class of exceptions that happen when an input or output signal fails
     * or is interrupted.
     */
    public void ReadFile() throws IOException {
        try{
            m_reader = new BufferedReader(new FileReader(m_file));
            while((m_line = m_reader.readLine()) != null) {
                String[] row = m_line.split(",");
                for(String index : row){
                    System.out.println(m_line);
                    break;//mo more indents!
                }
            }
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e) {
            e.printStackTrace();
        }
        finally{
            m_reader.close();
        }
    }

    /**
     * This method writes the name of the player and their score to a CSV file
     * @throws IOException
     * @param data the players name and their score in a string array
     */
    public void WriteFile(String[] data) throws IOException{

    }
}

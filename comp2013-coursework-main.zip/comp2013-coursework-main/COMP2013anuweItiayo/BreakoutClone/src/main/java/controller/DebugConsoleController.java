package controller;

import view.ballTypes.Ball;
import view.gameinterface.DebugConsole;
import view.gameinterface.DebugPanel;
import view.gameinterface.GameBoard;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
//try and change this to fx later
/**
 *This class is responsible for handling inputs from the user associated with the Debug window.
 *Changes:
 *1. getters and setters added
 *2. changed variable names to begin with m_
 *3. implemented the singleton design pattern for this class
 */
public class DebugConsoleController implements WindowListener {

    private DebugConsole m_debugConsole;
    private DebugPanel m_debugPanel;
    private GameBoard m_gameBoard;
    private static DebugConsoleController m_debugConsoleController;
    /**
     *
     * @return the game board that the user is playing on
     */
    public GameBoard getM_gameBoard() {
        return m_gameBoard;
    }

    /**
     *
     * @param m_gameBoard sets the value of the game board
     */
    public void setM_gameBoard(GameBoard m_gameBoard) {
        this.m_gameBoard = m_gameBoard;
    }

    /**
     *
     * @return gets the debug console (window that contains the debug panel)
     */
    public DebugConsole getM_debugConsole() {
        return m_debugConsole;
    }

    /**
     *
     * @param m_debugConsole the current console being used for debugging
     */
    public void setM_debugConsole(DebugConsole m_debugConsole) {
        this.m_debugConsole = m_debugConsole;
    }

    /**
     *
     * @return the panel which contains the debug features
     */
    public DebugPanel getM_debugPanel() {
        return m_debugPanel;
    }

    /**
     *
     * @param m_debugPanel the panel used to contain the debugging features
     */
    public void setM_debugPanel(DebugPanel m_debugPanel) {
        this.m_debugPanel = m_debugPanel;
    }

    /**
     * A constructor that initialises the game board, debug console, and debug panel
     * @param gb the game board
     */
    private DebugConsoleController(GameBoard gb){
        setM_gameBoard(gb);
        setM_debugConsole(gb.GetM_debugConsole());
        setM_debugPanel(getM_debugConsole().GetM_debugPanel());
        getM_debugConsole().addWindowListener(this);
    }
public static DebugConsoleController DebugConsoleInstance(GameBoard gb){
        if(m_debugConsoleController == null){
            m_debugConsoleController = new DebugConsoleController(gb);
        }
        return m_debugConsoleController;
}

    /**
     * This method determines what will happen when the window is opened.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowOpened(WindowEvent windowEvent) {

    }

    /**
     * This method determines what will happen when the window is closing.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowClosing(WindowEvent windowEvent) {
        m_gameBoard.repaint();
    }

    /**
     * This method determines what will happen when the window is closed.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowClosed(WindowEvent windowEvent) {

    }

    /**
     * This method determines what will happen when the window is iconified.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowIconified(WindowEvent windowEvent) {

    }

    /**
     * This method determines what will happen when the window is deiconified.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowDeiconified(WindowEvent windowEvent) {

    }

    /**
     * This method determines what will happen when the window is activated.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowActivated(WindowEvent windowEvent) {
        getM_debugConsole().SetLocation();
        Ball b = getM_debugConsole().GetM_wall().GetBall();
        getM_debugPanel().SetValues(b.GetM_speedX(), b.GetM_speedY());
    }

    /**
     * This method determines what will happen when the window is deactivated.
     * @param windowEvent an event that indicates that a window has changed its status
     */
    @Override
    public void windowDeactivated(WindowEvent windowEvent) {

    }
}

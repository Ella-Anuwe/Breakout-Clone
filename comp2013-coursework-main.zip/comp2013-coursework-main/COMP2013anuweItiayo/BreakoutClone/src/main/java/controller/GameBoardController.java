package controller;

import view.gameinterface.GameBoard;
import view.gameinterface.GameFrame;

import java.awt.*;
import java.awt.event.*;

/**
 * This class is responsible for handling inputs to do with the game board. It implements KeyListener,
 * MouseListener, and MouseMotionListener interfaces so that the GameBoard knows how to respond to inputs
 * from the mouse and keyboard.
 *Changes made:
 *1. Implemented singleton design pattern
 *2. Changed the name of variables
 *3.
 */
public class GameBoardController implements KeyListener, MouseListener, MouseMotionListener{
//
    boolean m_isPink;
    //make constructor
    private GameFrame m_gf;
    private GameBoard m_view;
    private static GameBoardController m_gameBoardController = null;
    /**
     * Constructior used to initialise the game board controller
     * @param isPink lets the controller know
     */
    private GameBoardController(boolean isPink){
       // this.m_isPink = isPink;
       // m_gf = Game
        m_gf = new GameFrame(isPink);
        m_view = m_gf.SetGameBoard();
        m_view.addKeyListener(this);
        m_view.addMouseListener(this);
        m_view.addMouseMotionListener(this);
    }

public static GameBoardController GameBoardControllerInstance(boolean isPink){
//
//        if(m_gameBoardController == null){
//        return new GameBoardController(isPink);
//    }
        return new GameBoardController(isPink);
}



    /**
     * In the event that a keyboard key is typed
     * @param keyEvent input from the keyboard
     */
    @Override
    public void keyTyped(KeyEvent keyEvent) {
    }

    /**
     * In the event that a keyboard key is pressed
     * @param e input from the keyboard
     */
    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) {
            m_view.GetM_wall().GetPlayer().moveLeft();
        }
        if (code == KeyEvent.VK_RIGHT) {
            m_view.GetM_wall().GetPlayer().movRight();
        }
        if (code == KeyEvent.VK_SPACE) {
            if (!m_view.GetM_showPauseMenu())
                if (m_view.GetM_gameTimer().isRunning())
                    m_view.GetM_gameTimer().stop();
                else
                    m_view.GetM_gameTimer().start();
        }
        if (code == KeyEvent.VK_ESCAPE) {
            boolean showPauseMenu = m_view.GetM_showPauseMenu();
            showPauseMenu = !showPauseMenu;
            m_view.SetM_showPauseMenu(showPauseMenu);
            m_view.repaint();
            m_view.GetM_gameTimer().stop();
            //might not work
        }
        if (code == KeyEvent.VK_SPACE) {
            if (e.isAltDown() && e.isShiftDown())
                m_view.GetM_debugConsole().setVisible(true);
        }
    }

    /**
     * determines what happens when a keyboard key is released
     * @param keyEvent input from the keyboard
     */
    @Override
    public void keyReleased(KeyEvent keyEvent) {
        m_view.GetM_wall().GetPlayer().stop();
    }

    /**
     * determines what happens when the mouse is clicked
     * @param mouseEvent an input coming from the mouse
     */
    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
        Point p = mouseEvent.getPoint();
        if (!m_view.GetM_showPauseMenu())
            return;
        if (m_view.GetM_continueButtonRect().contains(p)) {
            m_view.SetM_showPauseMenu(false);
            m_view.repaint();
        } else if (m_view.GetM_continueButtonRect().contains(p)) {
            m_view.SetM_message("Restarting Game...");
            m_view.GetM_wall().ballReset();
            m_view.GetM_wall().wallReset();
            m_view.SetM_showPauseMenu(false);
            m_view.repaint();
        } else if (m_view.GetM_exitButtonRect().contains(p)) {
            System.exit(0);
        }

    }

    /**
     * determines what happens when the mouse is moved
     * @param mouseEvent an input coming from the mouse
     */
    @Override
    public void mouseMoved(MouseEvent mouseEvent) {
        Point p = mouseEvent.getPoint();
        if (((m_view.GetM_exitButtonRect() == null) == false) && m_view.GetM_showPauseMenu()) {
            if (m_view.GetM_exitButtonRect().contains(p) || m_view.GetM_continueButtonRect().contains(p)
                    || m_view.GetM_restartButtonRect().contains(p))
                m_view.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            else
                m_view.setCursor(Cursor.getDefaultCursor());
        } else {
            m_view.setCursor(Cursor.getDefaultCursor());
        }
    }

    /**
     * In the event that the mouse enters the window
     * @param mouseEvent an input given from the mouse
     */
    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    /**
     * In the event that the mouse leaves the window
     * @param mouseEvent an input given from the mouse
     */
    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }

    /**
     * In the event that the user drags the mouse
     * @param mouseEvent an input given from the mouse
     */
    @Override
    public void mouseDragged(MouseEvent mouseEvent) {

    }

    /**
     * In the event that the user holds down the left mouse key
     * @param mouseEvent an input given from the mouse
     */
    @Override
    public void mousePressed(MouseEvent mouseEvent) {

    }

    /**
     * In the event that the user releases the left mouse key
     * @param mouseEvent an input given from the mouse
     */
    @Override
    public void mouseReleased(MouseEvent mouseEvent) {

    }
}


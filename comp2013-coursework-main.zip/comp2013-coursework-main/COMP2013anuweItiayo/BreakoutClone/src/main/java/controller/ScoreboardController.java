package controller;
import java.io.*;

/**
 * This class handles inputs from the user regarding the scoreboard, e.g.
 * taking in their names.
 */
public class ScoreboardController {
    /**
     * This method ensures that none of the inputs contain the wrong things. If it does, displays an
     * error message
     * @param data the players name and their score in a string array
     */
    public void SanitiseInput(String[] data){
        //an error should result in a message box displaying on the screen with an error message

    }


}
